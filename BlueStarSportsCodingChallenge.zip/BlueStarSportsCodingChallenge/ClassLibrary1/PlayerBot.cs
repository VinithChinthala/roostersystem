﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Objects
{
    public class PlayerBot
    {
        public int Speed { get; set; }
        public int Agility { get; set; }
        public int Strength { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public int TotalAttributeScore { get; set; }
        public PlayerBot(int s, int a,int st,string nm,string stt)
        {
            this.Speed=s;
            this.Status = stt;
           this.Agility=a;
            this.Strength=st;
            this.Name=nm;
            this.TotalAttributeScore = s + a + st;
        }
        public int CalcTotalAttributeScore()
        {
            int TotalAttributeScore = 0;
            TotalAttributeScore = Speed + Agility + Strength;
            return TotalAttributeScore;
        }
    }
}
