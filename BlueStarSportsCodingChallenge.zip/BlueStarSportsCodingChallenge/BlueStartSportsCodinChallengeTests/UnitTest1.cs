﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System.Collections.Generic;
using Objects;
using BlueStarSportsCodingChallenge;

namespace BlueStartSportsCodinChallengeTests
{
    [TestClass]
    public class UnitTest1
    {
        private TestContext testContextInstance;
        public TestContext TestContext1
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("%PathToWebRoot%\\WebSite", "/WebSite")]
        [UrlToTest("http://localhost/WebSite")]
        public void Test_getRoosterDetails()
        {
            List<PlayerBot> ExpectedList = new List<PlayerBot>(15);
            object res=Teams.getRoosterDetails(15, 175);
            Assert.AreEqual(ExpectedList, res, "Different result");
        }
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("%PathToWebRoot%\\WebSite", "/WebSite")]
        [UrlToTest("http://localhost/WebSite")]
        public void Test_GenerateName()
        {
            string Expectedstring = "";
            object res= Teams.generateName();
            Assert.AreEqual(Expectedstring, res, "Different result");
        }
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("%PathToWebRoot%\\WebSite", "/WebSite")]
        [UrlToTest("http://localhost/WebSite")]
        public void Test_getAttributeValues()
        {
            int[] ExpectedList = new int[3];
            Object res=Teams.getAttributeValues(25);
            Assert.AreEqual(ExpectedList, res, "Different result");
        }
    }
}
