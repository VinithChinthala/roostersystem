﻿using System;
using System.Collections.Generic;
using System.Web;
using BlueStarSportsCodingChallenge;
using Objects;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace BlueStarSportsCodingChallenge
{
    public partial class Teams : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lvDataBind();
            }
        }

        /*Method to remove an element off an array at given index value*/
        public static int[] remove(int[] array, int index)
        {
            var foos = new List<int>(array);
            foos.RemoveAt(index);
            return foos.ToArray();
        }
        /*Method to generate alphanumeric string for unique Player bot names*/
        public static string generateName()
        {
            string alphapool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var builder = new StringBuilder();
            string c = new string(
        Enumerable.Repeat(alphapool, 3)
                  .Select(s => s[new Random().Next(s.Length)])
                  .ToArray());
            builder.Append(c);
            var d = new Random().Next(101, 999);
            builder.Append(d);
            return builder.ToString();
        }
        /*Method to generate random numbers based on the given criteria of upperbound and lowerbound with no duplicates*/
        public static int[] geenrateRandomNumbers(int count, int total, int lowerbound, int upperbound)
        {
            int[] result = new int[count];
            int[] sumset = new int[18];
            for (int k = 0; k < 18; k++)
            {
                sumset[k] = ((k + 1) * (k + 2) / 2);
            }
            Random rnd = new Random();
            int currentsum = total;
            for (int i = 0; i < count; i++)
            {

                int j = 0;
                do
                {
                    j = rnd.Next(lowerbound, upperbound);
                } while (result.Contains(j));

                result[i] = j;

                currentsum = currentsum - result[i];
                int[] newset = sumset.Where(x => x < currentsum).ToArray();
                int nearestint = newset.Max();
                upperbound = newset.ToList().IndexOf(nearestint) + 1 + (currentsum - nearestint);
                remove(newset, upperbound - 1 - (currentsum - nearestint));
                if (i == count - 1)
                {
                    result[count - 1] = currentsum;
                }
            }
            return result;
        }
        /*Method to randomly assign scpres for each attribute of a player bot*/
        public static int[] getAttributeValues(int Totalattributescore)
        {
            int[] result = new int[3];
            result[0] = new Random().Next(0, Totalattributescore);
            result[1] = new Random().Next(0, Totalattributescore - result[0]);
            result[2] = Totalattributescore - result[1] - result[0];
            return result;
        }

        /*Method to genrate rooster with the ,randomly generated Total Attribute scores, Unique names, 
         Each atribute Scores etc.This method mainly creates PlayerBot objects and a List of Player bots*/

        public static List<PlayerBot> getRoosterDetails(int count, int total)
        {
            int[] result = new int[count];
            result = geenrateRandomNumbers(count, total, 1, 70);
            List<PlayerBot> Rooster = new List<PlayerBot>();
            foreach (int i in result)
            {
                int[] attributes = new int[3];
                attributes = getAttributeValues(i);
                string Name;
                do
                {
                    Name = generateName();
                } while (Rooster.Select(x => x.Name).Contains(Name));
                PlayerBot playerbot = new PlayerBot(attributes[0], attributes[1], attributes[2], Name, result.ToList().IndexOf(i) > 9 ? "Substitute" : "Starter");
                Rooster.Add(playerbot);
            }
            return Rooster;
        }

        public void lvDataBind()
        {
            int count = 15;
            int totalteamscore = new Random().Next(168, 175);
            List<PlayerBot> arrAttributeScores = getRoosterDetails(count, totalteamscore);
            Session["rooster"] = arrAttributeScores;
            lblteamrooster.Text = "Team's Rooster: " + arrAttributeScores.Sum(i => i.TotalAttributeScore).ToString();
            lvRooster.DataSource = arrAttributeScores;
            lvRooster.DataBind();
        }


        protected void hypFullRooster_Click(object sender, EventArgs e)
        {
            lvDataBind();
        }

        protected void hypStarters_Click(object sender, EventArgs e)
        {
            int count = 15;
            int totalteamscore = new Random().Next(168, 175);
            List<PlayerBot> arrAttributeScores = getRoosterDetails(count, totalteamscore);
            lvRooster.DataSource = arrAttributeScores.Where(i => i.Status == "Starter");
            lvRooster.DataBind();
        }

        protected void HypSubstitutes_Click(object sender, EventArgs e)
        {
            int count = 15;
            int totalteamscore = new Random().Next(168, 175);
            List<PlayerBot> arrAttributeScores = getRoosterDetails(count, totalteamscore);
            lvRooster.DataSource = arrAttributeScores.Where(i => i.Status == "Substitute"); ;
            lvRooster.DataBind();
        }

        
    }
}